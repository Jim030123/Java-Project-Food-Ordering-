public interface Cart {
    Food[] shoppingCart = new Food[100];

void addFood(Food food);
    
}
