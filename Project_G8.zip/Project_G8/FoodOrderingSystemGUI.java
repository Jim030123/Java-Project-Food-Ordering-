import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class FoodOrderingSystemGUI extends JFrame implements Cart {

    static ArrayList<Food> foodCollection = new ArrayList<Food>();
   
  
    private JTable foodTable;
    private DefaultTableModel tableModel;
    private JButton orderButton;

    public FoodOrderingSystemGUI() {
        setTitle("Food Ordering System");
        setSize(600, 500); // Increased the height to accommodate the button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Item ID");
        tableModel.addColumn("Item Name");
        tableModel.addColumn("Price");

        foodTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(foodTable);

        orderButton = new JButton("Place Order"); 
         goBackButton = new JButton("Place Order");// Create a button
        orderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
             
                JOptionPane.showMessageDialog(FoodOrderingSystemGUI.this, "Order placed!");
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(orderButton);

        // Use BorderLayout to position the table at the center and the button at the bottom
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        populateTable();

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void populateTable() {
        String[] type = { "Meal", "Beverage", "Snack" };

        // Food[] foodCollection = {
        //     new Meal("M01", "Chicken Burger", 7.50, type[0]),
        //     new Meal("M02", "Cheese Burger", 6.50, type[0]),
        //     new Meal("M03", "Beef Burger", 8.50, type[0]),
        //     new Meal("M04", "Pepperoni Pizza", 8.50, type[0]),
        //     new Meal("M05", "fried Chicken", 7.50, type[0]),
        //     new Meal("M06", "Spaghetti", 8.50, type[0]),
        //     new Beverage("B01", "Cola Cola", 3.00, type[1]),
        //     new Beverage("B02", "Mountain Dew", 3.00, type[1]),
        //     new Beverage("B03", "Spirit", 3.00, type[1]),
        //     new Beverage("S01", "Chicken nuggets", 9.00, type[2]),
        //     new Snack("S02", "Cheese potato", 7.00, type[2]),
        //     new Snack("S03", "French Fries", 8.00, type[2])
        // };
     

       
         foodCollection.add(new Meal("M01", "Chicken Burger", 7.50, type[0]));
         foodCollection.add(new Meal("M02", "Cheese Burger", 6.50, type[0]));
         foodCollection.add(new Meal("M03", "Beef Burger", 8.50, type[0]));
         foodCollection.add(new Meal("M04", "Pepperoni Pizza", 8.50, type[0]));
         foodCollection.add(new Meal("M05", "Fried Chicken", 7.50, type[0]));
         foodCollection.add(new Meal("M06", "Spaghetti", 8.50, type[0]));
         foodCollection.add(new Beverage("B01", "Cola Cola", 3.00, type[1]));
         foodCollection.add(new Beverage("B02", "Mountain Dew", 3.00, type[1]));
         foodCollection.add(new Beverage("B03", "Spirit", 3.00, type[1]));
         foodCollection.add(new Beverage("S01", "Chicken nuggets", 9.00, type[1]));
         foodCollection.add(new Snack("S02", "Cheese potato", 7.00, type[2]));
         foodCollection.add(new Snack("S03", "French Fries", 8.00, type[1]));
         foodCollection.add(new Snack("S03", "French Fries", 8.00,type[1]) );
        for (Food food : foodCollection) {
            if (food != null) {
                tableModel.addRow(new Object[]{food.getID(), food.getName(), food.getPrice()});
            }
        }
        
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new FoodOrderingSystemGUI();
        });
    }

    @Override
    public void addFood(Food food) {

        System.out.println(shoppingCart +"1");
       
    }
    // private void showMealForm() {
    //     String id = JOptionPane.showInputDialog(this, "Enter ID:");
    //     String name = JOptionPane.showInputDialog(this, "Enter Name:");
    //     double price = Double.parseDouble(JOptionPane.showInputDialog(this, "Enter Price:"));
    
    //     Meal newMeal = new Meal(id, name, price, "Meal");
    //     foodCollection.add(newMeal);
    
    //     tableModel.addRow(new Object[]{newMeal.getID(), newMeal.getName(), newMeal.getPrice()});
    // }
    
    // private void showBeverageForm() {
    //     String id = JOptionPane.showInputDialog(this, "Enter ID:");
    //     String name = JOptionPane.showInputDialog(this, "Enter Name:");
    //     double price = Double.parseDouble(JOptionPane.showInputDialog(this, "Enter Price:"));
    
    //     Beverage newBeverage = new Beverage(id, name, price, "Beverage");
    //     foodCollection.add(newBeverage);
    
    //     tableModel.addRow(new Object[]{newBeverage.getID(), newBeverage.getName(), newBeverage.getPrice()});
    // }
    
    // private void showSnackForm() {
    //     String id = JOptionPane.showInputDialog(this, "Enter ID:");
    //     String name = JOptionPane.showInputDialog(this, "Enter Name:");
    //     double price = Double.parseDouble(JOptionPane.showInputDialog(this, "Enter Price:"));
    
    //     Snack newSnack = new Snack(id, name, price, "Snack");
    //     foodCollection.add(newSnack);
    
    //     tableModel.addRow(new Object[]{newSnack.getID(), newSnack.getName(), newSnack.getPrice()});
    // }
}


